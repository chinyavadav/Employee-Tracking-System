<?php
include("connection.php");
$markers=Array();
if(isset($_GET["ecno"])){ 
	$ecno=mysqli_real_escape_string($conn,$_GET['ecno']);
	$statement="SELECT * FROM  tblemployees";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){
		$today=date('Y-m-d');
     	$stmt="SELECT MAX(fldlocation_id),tbllocations.fldemployee_id,fldphone_no,fldforename,fldsurname,fldrole,fldlatitude,fldlongitude,fldtimestamp FROM tbllocations JOIN tblemployees ON tbllocations.fldemployee_id=tblemployees.fldemployee_id WHERE tbllocations.fldemployee_id='$record[fldemployee_id]'";// and tbllocations.fldtimestamp LIKE '$today%'
     	$qry=mysqli_query($conn,$stmt) or die(mysqli_error($conn));
     	$rec=mysqli_fetch_assoc($qry);
     	if($rec["MAX(fldlocation_id)"]!=null){
     		$markers[]=$rec;
     	}
     }
 }
 echo json_encode($markers);
 ?>