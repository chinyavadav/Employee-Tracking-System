<?php
	include("connection.php");
	if(isset($_GET["ecno"])){
		$ecno=mysqli_real_escape_string($conn,$_GET["ecno"]);
		$date=date('Y-m-d');
		$statement="SELECT * FROM tblemployees";
		$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
		$employees=array();
		while($record=mysqli_fetch_assoc($query)){
			$employees[]=$record;
		}
		echo json_encode($employees);
	}
?>