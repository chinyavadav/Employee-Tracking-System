<?php
include("connection.php");
if($_SERVER["REQUEST_METHOD"]=="POST"){        
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {
        $request = json_decode($postdata);
        $phoneno =mysqli_real_escape_string($conn,$request->phoneno);
        $forename = mysqli_real_escape_string($conn,$request->forename);
        $surname = mysqli_real_escape_string($conn,$request->surname);
        $role = mysqli_real_escape_string($conn,$request->role);
        $password = mysqli_real_escape_string($conn,$request->password);

        $statement="INSERT INTO tblemployees(fldphone_no,fldforename,fldsurname,fldrole,fldpassword) VALUES ('$phoneno','$forename','$surname','$role',md5('$password'))";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $response['response']='success';

    } else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
}
?>