<?php
include("connection.php");
if($_SERVER["REQUEST_METHOD"]=="POST"){        
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {
        $request = json_decode($postdata);
        $employee_id =mysqli_real_escape_string($conn,$request->employee_id);
        $summary = mysqli_real_escape_string($conn,$request->summary);
        $stmt="SELECT MAX(fldid) FROM tblworkinghours WHERE fldemployee_id='$employee_id' and fldcheckout=''";
        $query=mysqli_query($conn,$stmt) or die(mysqli_error($conn));
        if(mysqli_num_rows($query)==1){
            $date=time();
            $statement="INSERT INTO tblworkinghours(fldemployee_id,fldcheckin,fldsummary) VALUES ('$employee_id','$date','$summary')";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            $response['response']='success';
        }else{
            $response=array("response"=>"failed");
        }
    } else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
}
?>