<?php
include("connection.php");
if($_SERVER["REQUEST_METHOD"]=="POST"){        
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {
        $request = json_decode($postdata);
        $employee_id =mysqli_real_escape_string($conn,$request->employee_id);
        $statement="SELECT MAX(fldid),fldcheckin FROM tblworkinghours WHERE fldemployee_id='$employee_id'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        if(mysqli_num_rows($query)==1){
            $rec=mysqli_fetch_assoc($query);
            $id=$rec["MAX(fldid)"];
            $checkin=$rec["fldcheckin"];
            $checkout=time();
            $hours=(int)$checkout-(int)$checkin;
            $statement="UPDATE tblworkinghours SET fldcheckout='$checkout',fldhours='$hours' WHERE fldid='$id'";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            $response['response']='success';
        }
    } else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
}

function timeDiff($x,$y){
    return (int)$y-(int)$x;
}
?>