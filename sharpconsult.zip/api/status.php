<?php
include("connection.php");
$record=Array();
if(isset($_GET["ecno"])){ 
	$ecno=mysqli_real_escape_string($conn,$_GET['ecno']);
     $statement="SELECT * FROM  tblworkinghours WHERE fldemployee_id='$ecno' and fldcheckout IS NULL";
     $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
     if(mysqli_num_rows($query)==1){
     	$record=mysqli_fetch_assoc($query);
     }
}
echo json_encode($record);
?>