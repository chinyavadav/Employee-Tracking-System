CREATE TABLE tblemployees(
	fldemployee_id int auto_increment,
	fldphone_no varchar(20) UNIQUE,
	fldforename varchar(20),
	fldsurname varchar(20),
	fldrole varchar(20),
	fldpassword varchar(32),
	primary key (fldemployee_id)
);

CREATE TABLE tbllocations(
	fldlocation_id int auto_increment,
	fldemployee_id int,
	fldtimestamp varchar(20),
	fldlatitude varchar(20),
	fldlongitude varchar(20),
	primary key (fldlocation_id),
	foreign key (fldemployee_id) references tblemployees(fldemployee_id)
);

CREATE TABLE tblworkinghours(
	fldid int auto_increment,
	fldemployee_id int,
	fldcheckin varchar(20),
	fldcheckout varchar(20),
	fldsummary varchar(200),
	primary key (fldid),
	foreign key (fldemployee_id) references tblemployees(fldemployee_id)
);